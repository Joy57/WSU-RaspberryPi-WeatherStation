#config file containing credentials for rds mysql instance
# db_host = "weatherdbinstance.c3abupa67dux.us-east-2.rds.amazonaws.com"
db_host ="weatherdbprototype1.c3abupa67dux.us-east-2.rds.amazonaws.com"
db_username = "prowsu"
db_password = "wsucapstone2018"
db_name = "weatherstation"
